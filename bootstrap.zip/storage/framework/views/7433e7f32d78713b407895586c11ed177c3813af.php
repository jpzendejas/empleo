<?php $__env->startSection('content'); ?>
<table summary="" align="center" width="550" cellpadding="8px">
<tr>
	<td width="33.33%">&nbsp;</td>
	<td width="33.33%">&nbsp;</td>
	<td width="33.33%">&nbsp;</td>
</tr>
<!-- <table border="0"> -->
  <tr>
    <td valign="top">
	    <font face="verdana" size="2" color="#5C2A3D"> PRESIDENTA MUNICIPAL DE SALAMANCA, GTO.  </font><br/>
			<font face="arial" size="2" color="#000000"><b><u>LIC. MARÍA BEATRIZ HERNÁNDEZ CRUZ</u></b></font><br/>
			<font face="verdana" size="2" color="#bf931f"><b>PRESIDENTE MUNICIPAL</b></font><br/>
			<font face="arial" size="1" color="#424242"><b>Portal Octaviano Muñoz Ledo S/N, Zona Centro.</b></font><br/>
			<font face="arial" size="2" color="#424242"><b>Tel. (464) 641-4501, Ext. 1010, 1012</b></font><br/>
			<a href="mailto:beatriz.hernandez@salamanca.gob.mx"><font face="verdana" size="1" color="#5C2A3D"><b>beatriz.hernandez@salamanca.gob.mx</b></font></a><br/><br/><br/><br/>
	</td>

  <td valign="top"><font face="verdana" size="2" color="#5C2A3D">H. AYUNTAMIENTO</font><br/>
			<font face="arial" size="2" color="#000000"><b><u>JOS&Eacute; LUIS MONTOYA VARGAS</u></b></font><br/>
			<font face="verdana" size="2" color="#bf931f"><b>SINDICO</b></font><br/>
			<font face="arial" size="1" color="#424242"><b>Portal Octaviano Muñoz Ledo S/N, Zona Centro.</b></font><br/>
			<font face="arial" size="2" color="#424242"><b>Tel. (464) 641-4501, Ext. 1080</b></font><br/>
			<br/><br/><br/><br/></td>

  	<td valign="top"><font face="verdana" size="2" color="#5C2A3D">H. AYUNTAMIENTO</font><br/>
			<font face="arial" size="2" color="#000000"><b><u>MA DOLORES OCHOA ECHEVESTE</u></b></font><br/>
			<font face="verdana" size="2" color="#bf931f"><b>SINDICO</b></font><br/>
			<font face="arial" size="1" color="#424242"><b>Portal Octaviano Muñoz Ledo S/N, Zona Centro.</b></font><br/>
			<font face="arial" size="2" color="#424242"><b>Tel. (464) 641-4501, Ext. 1080</b></font><br/>
			<br/><br/><br/><br/>

			</td>

  </tr>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.directorio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>