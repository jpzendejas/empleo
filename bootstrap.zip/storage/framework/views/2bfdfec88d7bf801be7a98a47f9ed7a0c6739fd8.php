<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Bolsa de Empleo Salamanca, Guanajuato</title>
    <link rel="icon" href="/img/omc.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="colorlib.com">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <link href="/css/main.css" rel="stylesheet" />
    <!-- <link href="/css/styles.css" rel="stylesheet" /> -->

  </head>
  <body>
    <div class="header">
      <div class="header-left-panel">
        <div class="logo-wrap">
          <div class="logo">
            <!-- <img src="/img/logosalamanca.jpg" alt="Salamanca" width="250" height="75"> -->
          </div>
        </div>
      </div>
      </div>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="footer">
      <!-- <p>Portal Octaviano Muñoz Ledo s/n, Zona Centro. Telefono.(464)641-4500. <br><br>
        <a href="https://www.facebook.com/GobSalamanca/">
          <img align="top" src="/img/FB_logo.png" alt="">
        </a>
        <a href="https://twitter.com/GobSalamanca">
          <img align="top" src="img/Twitter_logo.png" alt="">
        </a> <br><br>
      Última Actualización: 03/05/2019.
    </p> -->
    </div>
</body>
</html>
