<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bolsa de Empleo Salamanca, Guanajuato</title>
<link rel="icon" href="/img/omc.ico">

<link href="css/styles.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="header">
  <div class="header-left-panel">
    <div class="logo-wrap">
      <div class="logo">
        <img src="/img/logosalamanca.jpg" alt="Salamanca" width="280" height="100">
      </div>
    </div>
  </div>
  <div class="header-right-panel">
    <br>
    <br>
    <div class="menu">
      <ul>
        <li class="marRight20"><a  href="<?php echo e(url('/inicio')); ?>">Inicio</a></li>
        <li class="marRight20"><a href="<?php echo e(url('/buscar')); ?>">Empleos</a></li>
        <li><a href="<?php echo e(url('/contactanos')); ?>">contáctanos</a></li>

        <!-- <li class="marRight20"><a class="active" href="<?php echo e(url('/contactanos')); ?>">contáctanos</a></li> -->
      </ul>
    </div>
  </div>
</div>
<!--- panel wrap div end -->
<?php echo $__env->yieldContent('content'); ?>
</div>
<!--- page wrap div end -->
<div class="footer">
  <p>Portal Octaviano Muñoz Ledo s/n, Zona Centro. Telefono.(464)641-4500. <br><br>
  <a href="https://www.facebook.com/GobSalamanca/">
    <img align="top" src="/img/FB_logo.png" alt="">
  </a>
  <a href="https://twitter.com/GobSalamanca">
    <img align="top" src="/img/Twitter_logo.png" alt="">
  </a> <br><br>
  Última Actualización: 20/05/2019.
</p>
</div>
</body>
</html>
