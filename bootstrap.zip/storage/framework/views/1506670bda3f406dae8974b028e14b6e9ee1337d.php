<?php $__env->startSection('content'); ?>
<?php echo e(Form::token()); ?>

<div id="chart1"></div>

<?php echo $chart1; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>