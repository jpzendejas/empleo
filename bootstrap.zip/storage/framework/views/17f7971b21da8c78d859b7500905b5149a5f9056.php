<?php $__env->startSection('content'); ?>
<?php echo e(Form::token()); ?>

<div class="s01">
  <form action="/buscarvacantes" method="get">
    <fieldset>
      <legend>Bolsa de Empleo Salamanca, Gto.</legend>
    </fieldset>
    <div class="inner-form">
      <div class="input-field first-wrap">
        <input id="search" name="puesto" type="text" placeholder="Puesto de Trabajo" />
      </div>
      <div class="input-field second-wrap">
      <select id="location" name="Ubicacion" style="width:250px; height:70px; border:1px solid #04467E;background-color:#FFFFFF;color:#2D4167;font-size:18px" onchange="this.style.width=200">
          <?php foreach($municipios as $municipio): ?>
          <option value="<?php echo e($municipio->id); ?>"><?php echo e($municipio->municipio); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="input-field third-wrap">
        <button class="btn-search" type="submit">Buscar</button>
      </div>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>