<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bolsa de Empleo Salamanca, Guanajuato</title>
<link rel="icon" href="/img/omc.ico">

<link href="/css/styles.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style media="screen">
input[type=text], input[type=password] {
width: 100%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
box-sizing: border-box;
}
/* Set a style for all buttons */
button {
background-color: #5c2d3f;
color: white;
padding: 14px 20px;
margin: 8px 0;
border: none;
cursor: pointer;
width: 170px;
height: 40px;
}

button:hover {
opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
width: auto;
padding: 10px 18px;
background-color: #5c2d3f;
color: #fcb600;
}

/* Center the image and position the close button */
.imgcontainer {
text-align: center;
margin: 24px 0 12px 0;
position: relative;
}

img.avatar {
width: 40%;
border-radius: 50%;
}

.container {
padding: 16px;
}

span.psw {
float: right;
padding-top: 16px;
}

/* The Modal (background) */
.modal {
display: none; /* Hidden by default */
position: fixed; /* Stay in place */
z-index: 1; /* Sit on top */
left: 0;
top: 0;
width: 100%; /* Full width */
height: 100%; /* Full height */
overflow: auto; /* Enable scroll if needed */
background-color: rgb(0,0,0); /* Fallback color */
background-color: rgba(0,0,0,0.5); /* Black w/ opacity */
padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
background: url(/img/logoarmas.jpg);
background-repeat: no-repeat;
background-size: cover;
margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
border: 1px solid #888;
width: 40%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
position: absolute;
right: 25px;
top: 0;
color: #000;
font-size: 35px;
font-weight: bold;
}

.close:hover,
.close:focus {
color: red;
cursor: pointer;
}

/* Add Zoom Animation */
.animate {
-webkit-animation: animatezoom 0.6s;
animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
from {-webkit-transform: scale(0)}
to {-webkit-transform: scale(1)}
}

@keyframes  animatezoom {
from {transform: scale(0)}
to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media  screen and (max-width: 300px) {
span.psw {
   display: block;
   float: none;
}
.cancelbtn {
   width: 100%;
}
}

</style>
</head>
<body>
<div class="header">
  <div class="header-left-panel">
    <div class="logo-wrap">
      <div class="logo">
        <!-- <img src="/img/logosalamanca.jpg" alt="Salamanca" width="250" height="75"> -->
      </div>
    </div>
  </div>
  </div>

<!--- panel wrap div end -->
<div class="page-wrap">
  <div class="page-wrapper">
    <div class="primary-content marRight30">
      <div class="mid-panel">
        <div class="panel">
          <div class="title">
            <h1>Bolsa de Empleo Salamanca, Gto.</h1>
            <h2>Empleos</h2>
          </div>
          <?php echo $__env->yieldContent('content'); ?>
        </div>
      </div>
    </div>
    <div class="sidebar">
      <div class="search-panel">
        <div class="content">
          <div class="title">
            <h1>Buscar Empleos</h1>
          </div>
          <div class="border"></div>
          <h2>Buscar en el sitio...</h2>
          <div class="searchbox">
            <form action="/buscarvacantes" method="get">
              <input type="text" id="search" name="puesto" placeholder="Puesto">
              <br>
              <input type="submit" value="Buscar">
            </form>

          </div>
        </div>
      </div>
      <div class="midpanel">
        <div class="content marginBottom">
          <div class="title">
            <h1>Accesos Directos</h1>
          </div>
          <div class="border"></div>
          <ul>

            <li><a href="/salamanca/pdfs/CONVOCATORIA_PEJ_2019.pdf" target="_blank">Premio Estatal de la Juventud 2019</a></li>
            <li><a href="http://www.salamanca.gob.mx/Transparencia/Transparencia.htm" target="_blank">Transparencia</a></li>
            <li><a href="http://saresalamanca.mx/sare/" target="_blank">SARE</a></li>
          </ul>
        </div>
      </div>
      <div class="midpanel">
        <div class="content">
          <div class="title">
            <h1>Twitter</h1>
          </div>
          <div class="border"></div>
          <div class="container">
            <div class="left marRigth20">
              <blockquote class="twitter-tweet" data-lang="es"><p lang="es" dir="ltr">La alcaldesa <a href="https://twitter.com/BettyHdezC?ref_src=twsrc%5Etfw">@BettyHdezC</a> continúa sus recorridos por las comunidades de <a href="https://twitter.com/hashtag/Salamanca?src=hash&amp;ref_src=twsrc%5Etfw">#Salamanca</a> para escuchar y atender las necesidades más importantes de la población; en esta ocasión visitó la comunidad San José de Mendoza. <a href="https://t.co/3QF5gBIZV5">pic.twitter.com/3QF5gBIZV5</a></p>&mdash; Gobierno Salamanca (@GobSalamanca) <a href="https://twitter.com/GobSalamanca/status/1123326892893986816?ref_src=twsrc%5Etfw">30 de abril de 2019</a></blockquote>
              <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!--- page wrap div end -->
<div class="footer">
  <p>Portal Octaviano Muñoz Ledo s/n, Zona Centro. Telefono.(464)641-4500. <br><br>
    <a href="https://www.facebook.com/GobSalamanca/">
      <img align="top" src="/img/FB_logo.png" alt="">
    </a>
    <a href="https://twitter.com/GobSalamanca">
      <img align="top" src="img/Twitter_logo.png" alt="">
    </a> <br><br>
  Última Actualización: 03/05/2019.
</p>
</div>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  h2= table.getElementsByTagName("h2");
  for (i = 0; i < h2.length; i++) {
    h3 = h2[i].getElementsByTagName("h3")[0];
    if (td) {
      txtValue = h3.textContent || h3.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        h2[i].style.display = "";
      } else {
        h2[i].style.display = "none";
      }
    }
  }
}
</script>


</body>
</html>
