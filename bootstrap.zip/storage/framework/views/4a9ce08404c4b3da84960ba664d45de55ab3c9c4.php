<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Bolsa de Empleo Salamanca, Guanajuato</title>
    <link rel="icon" href="/img/omc.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="colorlib.com">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <link href="/css/main.css" rel="stylesheet" />
  </head>
  <body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
