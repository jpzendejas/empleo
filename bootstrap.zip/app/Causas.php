<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Causas extends Model
{
  protected $guarded = [];
  protected $table='causas';
}
