<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EstadosCivil extends Model
{
  protected $guarded = [];
  protected $table='estados_civil';
}
