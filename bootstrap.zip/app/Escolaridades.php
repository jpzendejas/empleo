<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Escolaridades extends Model
{
  protected $guarded = [];
  protected $table='escolaridades';
}
