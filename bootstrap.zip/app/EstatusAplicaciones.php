<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EstatusAplicaciones extends Model
{
    protected $guarded = [];
    protected $table = 'estatus_aplicaciones';
}
