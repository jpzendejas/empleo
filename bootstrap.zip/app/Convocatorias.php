<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Convocatorias extends Model
{
    protected $guarded = [];
    protected $table='convocatorias';
}
