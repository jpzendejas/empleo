<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Prestaciones extends Model
{
    protected $guarded = [];
    protected $table='prestaciones';
}
