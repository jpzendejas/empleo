<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AplicacionesVacantes extends Model
{
    protected $guarded = [];
    protected $table='aplicaciones_vacantes';
    
}
