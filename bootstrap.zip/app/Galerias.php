<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Galerias extends Model
{
    protected $guarded = [];
    protected $table = 'galerias';
}
