<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VacantePrestaciones extends Model
{
    protected $guarded = [];
    protected $table='vacante_prestaciones';
}
