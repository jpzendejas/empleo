<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vacantes extends Model
{
    protected $guarded = [];
    protected $table='vacantes';
}
