@extends('layouts.search')
@section('content')
{{Form::token()}}
<div class="s01">
  <form action="buscarvacantes" method="get">
    <fieldset>
      <legend>Bolsa de Empleo Salamanca, Gto.</legend>
    </fieldset>
    <div class="inner-form">
      <div class="input-field first-wrap">
        <input id="search" name="puesto" type="text" placeholder="Puesto de Trabajo" />
      </div>
      <div class="input-field second-wrap">
      <select id="location" name="Ubicacion" style="width:250px; height:70px; border:1px solid #04467E;background-color:#FFFFFF;color:#2D4167;font-size:18px" onchange="this.style.width=200">
          @foreach($municipios as $municipio)
          <option value="{{$municipio->id}}">{{$municipio->municipio}}</option>
          @endforeach
        </select>
      </div>
      <div class="input-field third-wrap">
        <button class="btn-search" type="submit">Buscar</button>
      </div>
    </div>
  </form>
</div>
@endsection
